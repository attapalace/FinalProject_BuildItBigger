package com.examples.apps.atta.javajokelib;

public class JokeTeller {
    public String getJoke(){
        return "This is the joke from the java library";
    }
}
